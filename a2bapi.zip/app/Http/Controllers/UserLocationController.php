<?php
namespace App\Http\Controllers;

use App\Models\User;
use App\Models\UserLocation;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use Validator;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;


class UserLocationController extends Controller{
     /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }
    public function createLocation(Request $request)
    {
        $response = $this->validate($request, [
                'from' => 'required',
                'to' => 'required',
             
        ]
        );
        
        $location = new UserLocation();
        $location->from = $request->from;
        $location->to= $request->to;
        $location->user_id= app('request')->get('authUser')->id;
        $location->save();
        
        if($location->save()){
            $response = response()->json(
                [
                 
                        'success' => true,
                        'message' => 'Location saved',
                        'status' => 200
                        
                ]);
        }else{
            $response = response()->json(
                [
                  
                        'success' => false,
                        'message' => 'Location not saved',
                        'status' => 401
                        
                ]);
        }
        return $response;
    }

    public function getUserLocation(){
       
        $user_id = app('request')->get('authUser')->id;
        try {

             $user = User::find($user_id);
             
            $user_loc = $user->userLocations()->get();
            if ( count($user_loc) !=0  ){
            return json_encode([
            'user_location'=>[
                    'status'=>200,
                    'location'=>$user_loc
                ]]);
            } else{
                return json_encode([
                    'error'=>[
                        'status'=> 401,
                        'message'=> 'No location history'
                    ]]);
            }
        } catch ( Exception $e){
                return json_encode([
                    'error'=>[
                        'status'=> 401,
                        'message'=> 'User does not exist'
                    ]]);
            }
        // $user_cards;

    
    }
}